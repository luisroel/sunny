
mysql -u root -pKikakuka.01 esto_erp_db  < drop_unused_objects.sql
mysql -u root -pKikakuka.01 esto_erp_db  < menu_options.sql

mysql -u root -pKikakuka.01 esto_erp_db  < tberp_address.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_contact.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_customer_address.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_customer_contact.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_customer.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_master.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_product_component.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_product.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_provider_address.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_provider_contact.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_provider.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_quotation.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_range.sql
mysql -u root -pKikakuka.01 esto_erp_db  < tberp_submaterial.sql


mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_address.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_component.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_contact.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_customer.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_master.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_product.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_provider.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_quotation.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_range.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_delete_submaterial.sql

mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_addresses.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_component_list.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_components.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_contacts.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_custumers.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_masters.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_products.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_providers.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_quotations.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_quotation_submaterial.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_ranges.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_get_submaterials.sql

mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_address.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_component.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_contact.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_customer.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_master.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_product.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_provider.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_quotation.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_range.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_insert_submaterial.sql

mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_address.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_component.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_contact.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_customer.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_master.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_product.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_provider.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_quotation.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_range.sql
mysql -u root -pKikakuka.01 esto_erp_db  < sperp_update_submaterial.sql

