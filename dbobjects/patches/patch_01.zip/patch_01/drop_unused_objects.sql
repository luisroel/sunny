DROP PROCEDURE IF EXISTS `sperp_get_customer_addresses`;
DROP PROCEDURE IF EXISTS `sperp_insert_customer_address`;
DROP PROCEDURE IF EXISTS `sperp_delete_customer_address`;

DROP PROCEDURE IF EXISTS `sperp_get_provider_addresses`;
DROP PROCEDURE IF EXISTS `sperp_insert_provider_address`;
DROP PROCEDURE IF EXISTS `sperp_delete_provider_address`;

DROP PROCEDURE IF EXISTS `sperp_get_provider_contacts`;
DROP PROCEDURE IF EXISTS `sperp_insert_provider_contact`;
DROP PROCEDURE IF EXISTS `sperp_delete_provider_contact`;

DROP PROCEDURE IF EXISTS `sperp_get_customer_contacts`;
DROP PROCEDURE IF EXISTS `sperp_insert_customer_contact`;
DROP PROCEDURE IF EXISTS `sperp_delete_customer_contact`;